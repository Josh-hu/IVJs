export interface Tag {
  id: string;
  text: string;
}

export interface Poll {
  id: string;
  question: string;
  options: string[];
  votes: number[];
}

export interface VideoStats {
  id: string;
  title: string;
  views: number;
  likes: number;
  comments: number;
  publishDate: string;
}

export interface ContentIdea {
  id: string;
  title: string;
  category: 'top10' | 'trivia' | 'motivation' | 'tech';
  description: string;
  tags: string[];
}