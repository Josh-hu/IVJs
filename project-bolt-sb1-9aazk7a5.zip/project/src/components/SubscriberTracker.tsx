import React from 'react';
import { Users, Trophy } from 'lucide-react';

interface SubscriberTrackerProps {
  currentSubs: number;
  milestones?: number[];
  loading?: boolean;
  error?: string;
}

const SubscriberTracker = ({
  currentSubs,
  milestones = [1000, 5000, 10000, 50000, 100000],
  loading = false,
  error
}: SubscriberTrackerProps) => {
  const nextMilestone = milestones.find(m => m > currentSubs) || milestones[0];
  const progress = (currentSubs / nextMilestone) * 100;

  if (loading) {
    return (
      <div className="bg-black/50 border border-neon-cyan p-6 rounded-lg shadow-neon animate-pulse">
        <div className="h-6 bg-neon-cyan/20 rounded w-3/4 mb-4"></div>
        <div className="h-12 bg-neon-cyan/20 rounded mb-4"></div>
        <div className="h-2.5 bg-neon-cyan/20 rounded-full mb-4"></div>
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map((_, i) => (
            <div key={i} className="h-4 bg-neon-cyan/20 rounded w-2/3"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-black/50 border border-neon-red p-6 rounded-lg shadow-neon">
        <div className="flex items-center space-x-2 mb-4">
          <Users className="w-6 h-6 text-neon-red" />
          <h2 className="text-xl font-bold text-neon-red">Error Loading Subscribers</h2>
        </div>
        <p className="text-neon-red">{error}</p>
      </div>
    );
  }

  return (
    <div className="bg-black/50 border border-neon-cyan p-6 rounded-lg shadow-neon">
      <div className="flex items-center space-x-2 mb-4">
        <Users className="w-6 h-6 text-neon-cyan" />
        <h2 className="text-xl font-bold text-neon-cyan">Subscriber Tracker</h2>
      </div>

      <div className="text-center mb-6">
        <div className="text-4xl font-bold text-neon-green">
          {currentSubs.toLocaleString()}
        </div>
        <div className="text-neon-cyan">Current Subscribers</div>
      </div>

      <div className="mb-4">
        <div className="flex justify-between text-sm text-neon-cyan mb-1">
          <span>Progress to {nextMilestone.toLocaleString()} subscribers</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-black rounded-full h-2.5 border border-neon-cyan">
          <div
            className="bg-neon-green h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <div className="space-y-2">
        {milestones.map((milestone, index) => (
          <div
            key={index}
            className={`flex items-center space-x-2 ${
              currentSubs >= milestone ? 'text-neon-pink' : 'text-neon-cyan/50'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span>{milestone.toLocaleString()} subscribers</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubscriberTracker;