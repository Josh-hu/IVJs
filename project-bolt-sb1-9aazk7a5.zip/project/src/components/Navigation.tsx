import React from 'react';
import { Menu, Layout, BarChart, Users, Brain } from 'lucide-react';

const Navigation = () => {
  return (
    <nav className="bg-black border-b border-neon-cyan">
      <div className="container mx-auto flex justify-between items-center p-4">
        <div className="flex items-center space-x-4">
          <img 
            src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/ivjs-fun-club-logo.png" 
            alt="IVJs Fun Club Logo" 
            className="w-12 h-12 object-contain"
          />
          <span className="text-xl font-bold text-neon-cyan">IVJs Fun Club</span>
        </div>
        <div className="hidden md:flex space-x-8">
          <NavItem icon={<Layout className="text-neon-pink" />} text="Content Tools" />
          <NavItem icon={<Users className="text-neon-green" />} text="Engagement" />
          <NavItem icon={<BarChart className="text-neon-cyan" />} text="Analytics" />
          <NavItem icon={<Brain className="text-neon-pink" />} text="Ideas" />
        </div>
        <button className="md:hidden text-neon-cyan hover:text-neon-pink transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </div>
    </nav>
  );
};

const NavItem = ({ icon, text }: { icon: React.ReactNode; text: string }) => (
  <div className="flex items-center space-x-2 cursor-pointer group">
    {icon}
    <span className="text-neon-cyan group-hover:text-neon-pink transition-colors">{text}</span>
  </div>
);

export default Navigation;