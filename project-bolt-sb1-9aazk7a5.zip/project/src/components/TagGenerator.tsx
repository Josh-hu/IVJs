import React, { useState } from 'react';
import { Tag, Hash } from 'lucide-react';

const TagGenerator = () => {
  const [tags, setTags] = useState<string[]>([]);
  const [input, setInput] = useState('');

  const generateTags = () => {
    const suggestions = [
      'shorts', 'viral', 'trending', 'funfacts',
      'androidvsiphone', 'tech', 'motivation',
      'learningsomething', 'didyouknow', 'ivjsfunclub'
    ];
    
    const randomTags = [...new Set([
      ...tags,
      ...suggestions
        .sort(() => 0.5 - Math.random())
        .slice(0, 5)
    ])];
    
    setTags(randomTags);
  };

  const addTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && input.trim()) {
      setTags([...new Set([...tags, input.trim()])]);
      setInput('');
    }
  };

  return (
    <div className="bg-black/50 border border-neon-cyan p-6 rounded-lg shadow-neon">
      <div className="flex items-center space-x-2 mb-4">
        <Tag className="w-6 h-6 text-neon-pink" />
        <h2 className="text-xl font-bold text-neon-cyan">Tag Generator</h2>
      </div>
      
      <div className="flex space-x-2 mb-4">
        <div className="flex-1">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={addTag}
            placeholder="Add custom tag..."
            className="w-full px-4 py-2 bg-black/50 border border-neon-cyan text-neon-green placeholder-neon-cyan/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-pink focus:border-transparent"
          />
        </div>
        <button
          onClick={generateTags}
          className="px-4 py-2 bg-black border border-neon-pink text-neon-pink rounded-lg hover:bg-neon-pink hover:text-black transition-all duration-300"
        >
          Generate Tags
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {tags.map((tag, index) => (
          <div
            key={index}
            className="flex items-center space-x-1 bg-black/50 border border-neon-green text-neon-green px-3 py-1 rounded-full"
          >
            <Hash className="w-4 h-4" />
            <span>{tag}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TagGenerator;