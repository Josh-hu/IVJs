import React from 'react';
import Navigation from './components/Navigation';
import TagGenerator from './components/TagGenerator';
import SubscriberTracker from './components/SubscriberTracker';

function App() {
  const subscriberData = {
    currentSubs: 1712,
    loading: false,
    error: undefined
  };

  return (
    <div className="min-h-screen bg-dark">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <TagGenerator />
          <SubscriberTracker {...subscriberData} />
          
          {/* Placeholder for future components */}
          <div className="bg-black/50 border border-neon-cyan p-6 rounded-lg shadow-neon">
            <h2 className="text-xl font-bold text-neon-cyan mb-4">Video Analytics</h2>
            <p className="text-neon-green">Coming soon...</p>
          </div>
          
          <div className="bg-black/50 border border-neon-cyan p-6 rounded-lg shadow-neon">
            <h2 className="text-xl font-bold text-neon-cyan mb-4">Content Ideas</h2>
            <p className="text-neon-green">Coming soon...</p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;