/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        neon: {
          cyan: '#00ffff',
          green: '#39ff14',
          pink: '#ff00ff',
          red: '#ff0000'
        }
      },
      backgroundColor: {
        dark: '#000000',
      },
      boxShadow: {
        'neon': '0 0 5px theme(colors.neon.cyan), 0 0 20px theme(colors.neon.cyan)',
        'neon-hover': '0 0 10px theme(colors.neon.cyan), 0 0 30px theme(colors.neon.cyan)',
      }
    },
  },
  plugins: [],
};